#pragma once
#include <iostream>
#include <string>
#include "bst.h"
using namespace std;

class hashBST
{
private:
    int idx;
    BST * arrBst;
public:

    hashBST(int max){
        idx = max;
        arrBst = new BST[max];
    }

    void insert(string word){
        arrBst[word.length() % idx].insert(word);
    }

    void max(){
        cout << arrBst[0].TreeMax();
    }

    void min(){
        cout << arrBst[1].TreeMin();
    }

    bool search(string word){
        if (arrBst[word.length() % idx].search(word) == NULL){
            return false;
        }
        else return true;
    }
};