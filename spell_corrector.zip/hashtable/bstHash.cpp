
#include <iostream>
#include <fstream>
#include <string>
#include "hashBST.h"
#include "linkedList.h"





int main(int argc, char const *argv[])
{
    hashBST hbst(17);
    string temp;
    int maxLen = 0;
    fstream dict;
    dict.open("small.txt", ios::in);

    while(getline(dict, temp, ' ')){
            if(temp.length() > maxLen){
            maxLen = temp.length();
            }
            hbst.insert(temp);
    }

    if(hbst.search("telecommunication")){
        cout << "found";
    }
    else cout << "Not found";
    
    return 0;

}
