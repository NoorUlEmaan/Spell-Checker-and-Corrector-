#pragma once
#include <iostream>
#include <string>
using namespace std;

/////////////////BST

class treeNode
{
public:
    treeNode *left;
    treeNode *right;
    string data;
    treeNode *parent;
};

class BST
{

public:
    treeNode *root;

    BST()
    {
        root = NULL;
    }

    ////////// Inorder Traversal

    void InorderTraverse(treeNode *n )
    {
        if (n != NULL)
        {
            InorderTraverse(n->left);
            cout << n->data << " ";
            InorderTraverse(n->right);
        }
    }

    ////////// Postorder Traversal

    void PostorderTraverse(treeNode *n )
    {
        if (n == NULL)
            return;
        PostorderTraverse(n->left);
        PostorderTraverse(n->right);
        cout << n->data << " ";
    }

    ////////// Preorder Traversal

    void PreorderTraverse(treeNode *n)
    {

        if (n == NULL)
            return;

        cout << n->data << " ";
        PreorderTraverse(n->left);
        PreorderTraverse(n->right);
    }

    ////////// Insert in Tree

    void insert(string m)
    {
        treeNode *z = new treeNode();
        z->data = m;
        z->left = NULL;
        z->right = NULL;

        treeNode *y = NULL;
        treeNode *x = root;

        while (x != NULL)
        {

            y = x;
            if (x->data.compare(z->data) > 0)
                x = x->left;
            else
                x = x->right;
        }

        z->parent = y;
        if (root == NULL)
            root = z;
        else if (y->data.compare(z->data) < 0)
            y->right = z;
        else
            y->left = z;
    }

    ////////// Min Tree

    string TreeMin(treeNode *x = NULL)
    {
        if (x == NULL) //  to make function usable for both kind of function calls use in this code
            x = root;
        if (x->left != NULL)
            x = x->left;
        return x->data;
    }

    ////////// Max Tree

    string TreeMax(treeNode *x = NULL)
    {
        if (x == NULL)
            x = root;
        while (x->right != NULL)
        {
            x = x->right;
        }
        return x->data;
    }

    /////////// Tree Search

    treeNode *search(string s)
    {
        treeNode *cmp = root;
        while (cmp != NULL)
        {

        if(s.compare(cmp->data) < 0){
            cmp = cmp->left;
        }
        else if (s.compare(cmp->data) > 0)
        {
            cmp = cmp->right;
        }
        else{
            return cmp;
        }
        }
        return NULL;

    }

    ////////// Predecessor of x

    treeNode *Predecessor(string x)
    {
         treeNode *c = search(x);
        if (c->left != NULL)
        {
            string val = TreeMax(c->left);

            // TreeMin will return the minimum value not node containing that value, but this function has to return the node. How to handle it without changing TreeMin
            treeNode *rightSubTree = c->left;
            treeNode *predNode = NULL;
            while (rightSubTree->right != NULL)
            {
                predNode = rightSubTree;
                rightSubTree = rightSubTree->right;
            }
            return rightSubTree;
        }
        treeNode *y = c->parent;
        while (y != NULL && c == y->left)
        {
            c = y;
            y = y->parent;
        }
        return y;
    }

    ////////// Successor of x

    treeNode * Successor(string x)
    {
        treeNode *c = search(x);
        if (c->right != NULL)
        {
            string val = TreeMin(c->right);
            treeNode *leftSubTree = c->right;

            while (leftSubTree->left != NULL)
            {
                leftSubTree = leftSubTree->left;
            }
            return leftSubTree;
        }
        treeNode *y = c->parent;
        while (y != NULL && c == y->right)
        {
            c = y;
            y = y->parent;
        }
        return y;
    }

    ////////// Delete from tree

    void deleteNode(string x)
    {
        treeNode *c = search(x);
        // if to be deleted node is a leaf node
        if (c->left==NULL && c->right==NULL)
        {
            treeNode *y = c->parent;
            if (y->left==c)
                y->left = NULL;
            else
                y->right = NULL;
            delete c;
        }
        // if to be deleted node has both right and left childs
        else if (c->left!=NULL && c->right!=NULL)
        {
            treeNode *cSuccessor = Successor(x);
            string data = cSuccessor->data;
            deleteNode(cSuccessor->data);
            c->data = data;
            delete cSuccessor;
        }
        // if to be deleted node has either a left or a right child
        else
        {
            treeNode *prnt = c->parent;
            if (c->right!=NULL)
            {
                treeNode *chld = c->right;
                delete c;
                if (prnt->right==c)
                    prnt->right = chld;
                else
                    prnt->left = chld;
            }
            else
            {
                treeNode *chld = c->left;
                delete c;
                if (prnt->right==c)
                    prnt->right = chld;
                else
                    prnt->left = chld;
            }
        }
    }
};
