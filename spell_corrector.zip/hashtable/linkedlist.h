#pragma once

#include <istream>
#include<stdio.h>
#include <iostream>

using namespace std;

class node {
public:
    string data;
    node *next;
    node *prev;


    node(string val) {
        this->data = val;
        this->next = NULL;
        this->prev = NULL;
    }
};

class Doublylist {
private:
    node *head;
    int len;
    node *tail;

public:
    int getLen() {
        return len;
    }

    Doublylist() {
        head = NULL;
        len = 0;
        tail = NULL;
    }

    // insert at the start of the list
    void insertH(string y) {
        node *ins = new node(y);
        if (head == NULL) {
            head = ins;
            tail = ins;
            len++;
        } else {
            ins->next = head;
            head->prev = ins;
            head = ins;
            len++;
        }
    }

    // insert at the end of the list
    void insertT(string y) {
        node *ins = new node(y);
        if (head == NULL) {
            head = ins;
            tail = ins;
            len++;
        } else {
            tail->next = ins;
            ins->prev = tail;
            tail = ins;
            len++;
        }

    }

    // position starting from 0
    void insertAfter(string y, int pos) {

        if (pos >= 0 && pos < len) {
            node *start = head;
            node *ins = new node(y);
            if (pos == 0) {
                insertH(y);
                return;
            }
            for (int i = 0; i < pos - 1; i++) {
                start = start->next;
            }
            cout << "Start data" << start->data << endl;
            cout << "Start next" << start->next->data << endl;
            ins->next = start->next;
            start->next = ins;
            ins->prev = start;
            ins->next->prev = ins;
            len++;
        } else {
            return;
        }
    }

    // delete from the head/start of the list
    string deleteH() {
        if (head == NULL) {
            cout << "Already Empty \n";
            return NULL;
        }if(len==1){
            node *old = head;
            string oldVal = old->data;
            head->prev = NULL;
            head = head->next;
            delete old;
            len--;
            return oldVal;
        } else {
            node *old = head;
            string oldVal = old->data;
            head = head->next;
            head->prev = NULL;
            delete old;
            len--;
            return oldVal;
        }
    }


    // delete from the tail of the list and return the deleted value
    string deleteT() {
        if (head == NULL) {
            cout << "Already Empty\n";
            return NULL;
        } else if (head->next == NULL) {
            node *old = head;
            head = NULL;
            string oldVal = old->data;
            delete old;
            len--;
            return oldVal;
        } else {
            node *start = head;
            while (start->next->next != NULL) {
                start = start->next;
            }
            node *old = start->next;
            string oldVal = old->data;
            start->next = NULL;
            tail = start;
            len--;
            return oldVal;
        }

    }

    string deleteAt(int pos) {
        if (pos >= 0 && pos < len) {
            node *start = head;

            if (pos == 0) {
                len--;
                return deleteH();
            }
            if (pos == len) {
                cout << "No such index\n";
                return NULL;
            }
            for (int i = 0; i < pos - 1; i++) {
                start = start->next;
            }
            node *old = start->next;
            start->next = start->next->next;
            start->next->prev = old->prev;
            len--;
            string oldVal = old->data;
            delete old;
            return oldVal;
        } else {
            cout << "No such index\n";
            return NULL;
        }
    }


    //returns the no of node  being searched
    int search(string y) {
        if (head == NULL) {
            cout << "Already Empty\n";
            return -1;
        }
        int idx = 0;
        node *start = head;
        do {
            if (start->data == y) {
                cout << "Index: ";
                return idx;
            }
            start = start->next;
            idx++;
        } while (start != NULL && idx != len);
        cout << "No such element \n";
        return -1;
    }

    void print(string order = "") {
        if (order == "") {
            node *tptr = head;
            if (isEmpty()) {
                cout << "No elements\n";
                return;
            }
            while (tptr != NULL) {
                cout << tptr->data << " -> ";
                tptr = tptr->next;

            }
            cout << "NULL\nLength: " << len << endl;
        }
        if (order == "rev") {
            node *tptr = tail;
            if (isEmpty()) {
                cout << "No elements\n";
                return;
            }
            cout << "Reversed\n";
            while (tptr != NULL) {
                cout << tptr->data << " -> ";
                tptr = tptr->prev;

            }
            cout << "NULL\nLength: " << len << endl;
        }
    }

    string peek(){
        if(head != NULL){
            return head->data;
        }else{
            return " ";
        }
    }

    bool isEmpty() {
        return (head == NULL);
    }
};

